create table grupo (
	
	id_grupo bigint not null auto_increment,
	nome varchar(45) not null,
	descricao varchar(100) not null,
				
	primary key (id_grupo)
	
);