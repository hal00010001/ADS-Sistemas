create table categoria (
	
	id_categoria bigint not null auto_increment,
	descricao varchar(400),
			
	primary key (id_categoria)
	
);