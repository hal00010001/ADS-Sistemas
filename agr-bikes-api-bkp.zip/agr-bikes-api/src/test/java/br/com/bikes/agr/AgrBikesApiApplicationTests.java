package br.com.bikes.agr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgrBikesApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
